<?php
$errors ='';

$myEmail ='contactus@bedrockmarketer.co.za';

$fname=$_POST['name'];
$lname=$_POST['name'];
$email_address =$_POST['email'];
$message=$_POST['message'];

if(empty($errors)){

$to=$myEmail;
$email_subject ="Contact form submission:$fname";

$email_body="You have received a new message.".

"Here are the details:\n Name: $name \n ".

"Email: $email_address\n Message \n $message";

$headers = "From: $myemail\n";

$headers .= "Reply-To: $email_address";

$success=mail($to,$email_address,$email_subject,$email_body,$headers);

//redirect to the ‘thank you’ page

}

?>